# podkop-manager web UI: design handoff

Target: `manager/podkop_manager/static/` (app.html, app.js, app.css, login.html) in
github.com/dkagramanyan/podkop-keys-availability. Keep the current stack: plain DOM via `h()`,
hash routes, SSE from `/api/stream`. No framework, no build step.

The `design/*.dc.html` files are the reference screens. They are static mockups with sample
data and need the Design canvas runtime (`support.js`) to render, so read them as HTML/CSS
source, not as pages to serve. Copy layout, spacing, colors and copy text from them.

## Navigation (feature-first)

Left sidebar, top to bottom:
1. Brand `podkop-manager` + live dot (SSE connected).
2. Router switcher: current router name, host, state. Opens a list of all routers with
   state, plus "Add router" and "Manage routers" (both go to Settings). Under the switcher,
   one red line per other router that is offline or had a change undone.
3. Sections: Overview, Routing (sub: Rules, Global settings), Servers, Servers probe, Logs, History.
   Routing shows a badge with the number of unapplied draft changes.
4. Bottom: Settings.

The selected router is part of the route: `#/r/<id>/<section>`. Remember the last selected
router in localStorage. `#/` redirects to the last router's Overview; with no routers, to Settings.

| Screen | Design file | Route | API used |
|---|---|---|---|
| Overview | Main.dc.html | `#/r/:id` | `/api/routers`, `/config`, `/events`, `/probe`, `/service` |
| Routing rules | Routing.dc.html | `#/r/:id/rules` | `/config`, `/validate`, `/diff`, `/api/schema` |
| Global settings | Global.dc.html | `#/r/:id/global` | same as rules, `settings` section |
| Review and apply | Apply.dc.html (modal) | modal over rules/global/probe/history | `/diff`, `/apply`, `/api/versions/:vid` |
| Servers | Servers.dc.html | `#/r/:id/servers` | `proxies` from snapshot, `/pin`, `/delays` |
| Servers probe | Probe.dc.html | `#/r/:id/probe` | `/probe` GET/PUT, `/probe/start`, `/probe/preview` |
| Logs | Logs.dc.html | `#/r/:id/logs` | `/logs`, `/logs/recent`, SSE `log` |
| History | History.dc.html | `#/r/:id/history` | `/versions`, `/api/versions/:vid` |
| Settings | Settings.dc.html | `#/settings` | `/api/routers` POST/PATCH/DELETE, `/reinstall`, `/api/manager`, `/logout` |
| Router switcher | Switcher.dc.html | sidebar popover | `/api/routers` |
| Rule with servers by country | RuleCountry.dc.html | `#/r/:id/rules/:section` | rules API + new `auto_rules` (below) |
| Keys and usage | Usage.dc.html | `#/r/:id/usage` | new `/usage` API (below) |

## Key behaviours

- Routing rules: podkop `section`s shown as an ordered list "what matches -> where it goes";
  drag to reorder (first match wins); an implicit last row "Everything else -> Direct".
  Selecting a rule opens the editor panel: Matches (community lists as toggles, domains as
  chips, subnets, remote/local lists) and Sends to (Proxy / VPN / Block / Direct, then
  One link / Selector / Fastest (URLTest) / sing-box JSON). Server links are parsed into
  name, protocol, host. Advanced options sit in a collapsed block; changed fields show
  "was <old value>". Unknown options are kept untouched.
- Draft: edits on Rules and Global settings form one draft per router. A bar shows the
  number of changes, problems from Check, Discard, Check again, Review and apply.
  The draft survives page reloads (persist it, see backend below).
- Apply modal: diff grouped by rule, router-side check result, note for history, live steps
  (backup, write, restart, watch 30 s), and the auto-revert explanation.
- Rules with servers by country (RuleCountry.dc.html, example `netflix` -> Poland): in the
  rule editor, "Sends to" has two sources. "Links I add" is the current behaviour.
  "From my subscriptions" takes servers from the same subscription keys the probe uses,
  filtered by exit country (list of ISO codes), protocol (vless, trojan, ss, hysteria2,
  socks), optional exit IP or CIDR list, optional name substring, then keeps the N fastest
  plus M fallback, using the probe's ping and speed limits. The rule stays a normal podkop
  URLTest section; the manager rewrites its `urltest_proxy_links` /
  `urltest_fallback_links` after every probe run, the same way it does for main/youtube.
  The editor shows "Matches now" from the last probe (name, protocol, exit IP, median,
  Mbit/s), a warning when fewer than N match, and the servers left out with the reason.
  If nothing matches after a run, the rule keeps its last list and an event is raised.
  The Probe page lists these rules under "Into podkop", its results table shows them in
  "Goes to", and Servers shows the rule as a normal automatic group.
- Keys and usage (Usage.dc.html): one card per key (subscription or single link).
  Keys with a daily limit get the large card: used today of the limit, a progress bar with
  a mark at the action threshold (90%), a split by rule, a running-total chart for today
  with a dashed forecast to the limit (rate of the last 3 hours), and a footer with the
  limit source and the "At 90%" action. Other keys get compact cards (period usage,
  expiry, today's traffic). Below: last 14 days as bars with the limit line (days that
  hit the limit in the status red, with a "limit" label), and today's traffic by server.
  A warning banner and an Overview row appear when a key is forecast to hit its limit
  today. The sidebar item shows the highest daily-limit percentage.
- Servers: per selector/urltest group, delay bars, In use / Pin, Back to automatic, Test delays.
- Probe: subscriptions, filters, target rules, schedule and auto-apply on the left; last run
  totals, results table with "Goes to" and a reason for each rejected server, run history.
- Logs: search, source chips, level filter, Follow live, Load router buffer.
- History: versions with applied / undone / rejected, the reason box, expandable diff, Restore.

## Design tokens

Fonts: IBM Plex Sans 400/500/600 (UI), IBM Plex Mono 400/500 (links, hosts, rule names, logs).
Google Fonts link is in every design file.

| Token | Value | Use |
|---|---|---|
| ground | #F4F5F2 | page background |
| sidebar | #FBFBFA | sidebar background |
| surface | #FFFFFF | cards |
| sunken | #F9FAF8 | table heads, card footers |
| line | #E1E3DE | card borders |
| line-soft | #EDEEEA | row dividers |
| control-border | #CDD0C9 | inputs, secondary buttons |
| nav-active | #EBEDE8 | active nav item |
| text | #1A1D21 | body text |
| text-2 | #3B424B | secondary text |
| muted | #59616B | captions (passes 4.5:1 on white) |
| accent | #2457A6 | primary buttons, focus, active tab |
| accent-soft | #E8EEF8 / text #1F4A8C | selected chips, Proxy tag |
| ok | #2B6E43 on #E5F1E9, dot #2F8A52 | running, applied, added |
| warn | #8F4E00 on #FBEFD9 | flaky, rejected, pinned-warning |
| bad | #A8261B on #FBE7E4, dot #B42318 | offline, undone, errors |

Radii: cards 10px, buttons/inputs 6px, chips 4-5px, pills 11px.
Heights: buttons 36px (primary page actions 40px), small buttons 28-32px, inputs 34-36px.
Card padding 16-20px, page padding 28px clamp(16px, 3vw, 40px), content max-width 1160px.
Sidebar 240px; below ~800px it stacks above the content.

## Backend additions the design needs

1. Draft storage per router (table `drafts`: router_id, config JSON, base fingerprint,
   updated) with GET/PUT/DELETE `/api/routers/:id/draft`.
2. `/validate` problems already carry section/option/index. Keep `index` for list options so
   the UI can mark the exact server line.
3. Probe rows: a `reason` field for rejected servers (too slow, ping, exit IP country,
   device limit, unsupported protocol).
4. Logs: `source` (podkop, sing-box, engine, agent) and `level` per stored line, plus
   `source` and `level` query filters.
5. Version entries: `trigger` (web, probe, restore) and, for undone ones, the revert reason
   already sent in the event data.
6. Rules with servers by country:
   - table `auto_rules` (router_id, section, countries JSON, protocols JSON, exit_ips JSON,
     name_contains, top, fallback), GET/PUT/DELETE `/api/routers/:id/auto-rules/:section`.
     Stored on the manager; podkop's UCI config only ever sees the resulting links.
   - the probe must return every tested server with its link, protocol, exit IP and exit
     country (probe.sh already measures `exit_ip` and `country` through ipinfo.io and
     writes them to its CSV; pass them through `probe-status` rows together with the link).
   - after a run, for each auto rule: filter rows by the rule, drop servers that fail the
     probe's verdict/ping/speed limits, sort by median, take top + fallback, and merge into
     the config next to main/youtube (extend `podkop.merge_probe`). Nightly auto-apply
     covers these rules too; the result goes through the usual check and auto-revert.
   - `GET /api/routers/:id/auto-rules/:section/preview`: the "Matches now" list and the
     left-out servers with reasons, computed from the last probe run.
7. Keys and usage:
   - keys: today a key is one probe subscription URL. Add single links as keys too
     (name, link) and keep per key: label, limit source (`provider` or `manual`), manual
     limit in GB, period (`day`, `month`, `none`), reset time (default 00:00 in the
     manager's timezone), action at threshold (`warn` or `avoid`), threshold (default 90%).
   - provider numbers: fetch each subscription URL every 10 min with the same user agent
     and x-hwid the probe uses (`sub_fetch` in probe.sh) and parse the standard
     `subscription-userinfo` response header: `upload=<bytes>; download=<bytes>;
     total=<bytes>; expire=<unix>`. used = upload + download, limit = total (0 = none).
     Store samples in a `key_usage` table (key_id, t, used, total, expire) so the daily
     chart and 14-day history work, and so the period can be inferred when the provider
     resets daily.
   - router-side split: podkop-agent polls the Clash API `/connections` on the router
     (127.0.0.1:9090) every 30-60 s, sums upload+download deltas per outbound chain
     (`<section>-<n>-out`), and reports them. The manager maps outbound -> link -> key
     with `tag_names` and the link-to-key index, and stores per-key, per-rule and
     per-server counters per hour. Single-link keys use only this source.
   - action `avoid`: when a key passes its threshold, regenerate the URLTest lists of the
     affected rules without that key's servers (same merge path as the probe, through
     check and auto-revert), and put them back after the reset. Log both as events and
     history versions with trigger `usage`.
   - API: `GET /api/routers/:id/usage` (keys with today, period, forecast, by rule),
     `GET /api/routers/:id/usage/history?key=&days=14`, `GET /api/routers/:id/usage/servers?day=`,
     `PUT /api/keys/:key_id` for the limit settings.

## Suggested order

Shell and router switcher, Overview, Servers, Logs, History, Probe, Rules and Global with
the draft, Apply modal, Settings. Run `manager/tests` after each step.
